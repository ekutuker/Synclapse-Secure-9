﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Synclapse_Secure_9
{
    public partial class ProcessScanForm : Form
    {
        public int totalItems = 0;

        public ProcessScanForm()
        {
            InitializeComponent();
        }

        private void ProcessScanForm_Load(object sender, EventArgs e)
        {
            Process[] processes = Process.GetProcesses();

            foreach (Process netProcess in processes)
            {
                listBox1.Items.Add(Convert.ToString(netProcess.ProcessName));
            }

            getTotalListBoxItems();

        }

        void getTotalListBoxItems()
        {
            foreach (string Item in listBox1.Items)
            {
                totalItems = totalItems + 1;
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            string myString = textBox1.Text;
            bool found = false;
            for (int i = 0; i <= listBox1.Items.Count - 1; i++)
            {
                if (textBox1.Text == "" | textBox1.Text == " ")
                {
                    listBox1.SelectedItem = null;
                    break;
                }
                if (listBox1.Items[i].ToString().Contains(myString))
                {
                    listBox1.SetSelected(i, true);
                    listBox2.Items.Add(listBox1.SelectedItem);
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                listBox2.Items.Add("Nothing found!");
                listBox1.SelectedItem = null;
            }
        }
    }
}
