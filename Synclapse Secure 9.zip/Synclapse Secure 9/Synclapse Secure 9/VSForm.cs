﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Synclapse_Secure_9
{
    public partial class VSForm : Form
    {


        public static string[] blacklist =
        {

            "keylogger",
            "log_kbKeyPress(",
            "KeyPress",
            "smtp",
            "sendmail",
            "System.Net.Mail"

        };

        public static string[] coolNamesXD =
  {

            "Keylogger",
            "Keylogger(2)",
            "Listening keyPress()",
            "Possible SMTP Mailing",
            "Possible Mail Sending",
            "(Absolute) Using SYSNet.Mail"
           
        };

        public int checkedBlI = 0;
        public int detectedBlI = 0;

        public int totalItemsToSearchInTheFile = blacklist.Length;

        public string directory;

        public VSForm()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void VSForm_Load(object sender, EventArgs e)
        {
            textBox1.ReadOnly = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog cddialog = new OpenFileDialog
            {
                InitialDirectory = @"C:\",
                Title = "Browse a file to scan cheats & gamehacks.",

                CheckFileExists = true,
                CheckPathExists = true,

                FilterIndex = 2,
                RestoreDirectory = true,

                ReadOnlyChecked = true,
                ShowReadOnly = true
            };

            directory = cddialog.FileName;

            if (cddialog.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = cddialog.FileName;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            progressBar1.Maximum = totalItemsToSearchInTheFile;
            progressBar1.Minimum = 0;
            progressBar1.Value = 0;

            listBox1.Items.Clear();
            var fileName = @textBox1.Text;

            try
            {

                using (StreamReader reader = new StreamReader(fileName))
                {
                    if (totalItemsToSearchInTheFile != checkedBlI)
                    {
                        string line;

                        while ((line = reader.ReadLine()) != null)
                        {
                            for (int i = 0; i < blacklist.Length; i++)
                            {
                                if (!(i > checkedBlI))
                                {
                                    progressBar1.Value = i;

                                    if ((i == totalItemsToSearchInTheFile - 1))
                                    {
                                        progressBar1.Value = i + 1;
                                    }

                                    checkedBlI++;


                                    if (line.Contains(blacklist[i]))
                                    {
                                        detectedBlI++;
                                        listBox1.Items.Add(coolNamesXD[i]);
                                    }
                                }

                            }
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }

            if (detectedBlI == 0)
            {
                MessageBox.Show("Nothing found!", "Secure 9", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

            label2.Text = "Total Detected: " + detectedBlI.ToString();
            detectedBlI = 0;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
