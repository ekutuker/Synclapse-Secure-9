﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Synclapse_Secure_9
{
    public partial class CheatScanForm : Form
    {
        public CheatScanForm()
        {
            InitializeComponent();
        }

        public string[] blacklist =
        {

            "cheat",
            "triggerbot",
            "ReadMemory",
            "WriteMemory",
            "csgocheat",
            "Atom Premium",
            "Aimware",
            "EzGlobal",
            "aimbot",
            "ESP",
            "glowhack",
            "Glowesp",
            "chams",
            "radarhack",
            "aimhack",
            "visuals",
            "perfect nade",
            "bunnyhop",
            "bhop",
            "clantag",
            "weaponspammer",
            "dwGlowObject",
            "m_iHealth",
            "^ûûÅf{Ğd°¾{³ä‚"


        };

        public string[] coolNamesXD =
  {

            "pbCheat.generic()",
            "gHack_64 (mTriggerBot)",
            "86_detectM_ReadProcessMemory()",
            "86_detectM_WriteProcessMemory()",
            "cheats.CSGO",
            "cheats.Atom_Premium(1)",
            "cheats.Aimware",
            "cheats.EzGlobalTR_64",
            "cheats.Q86(Aimbot)",
            "cheats.ESP",
            "cheats.GlowHack64",
            "r.net_GlowHack",
            "r.net_32Chams",
            "r.net_RadarHack",
            "r.net_AimHack",
            "r.net_Visuals",
            "c86_PfNadeException",
            "mod_bhopAuto64",
            "mod_bhopAuto86",
            "mod_cTagger",
            "rs_weaponSpam",
            "CSNET_dwGlowObject(inuse)",
            "CSNET_m_iHealth(inuse)",
            "cheats.Atom_Premium(2)"
        };


        public int atl;

        public int totalDetections = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            totalDetections = 0;
            label2.Text = totalDetections.ToString();

            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = @"C:\",
                Title = "Browse a file to scan cheats & gamehacks.",

                CheckFileExists = true,
                CheckPathExists = true,

                FilterIndex = 2,
                RestoreDirectory = true,

                ReadOnlyChecked = true,
                ShowReadOnly = true
            };

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = openFileDialog1.FileName;
                button2.Show();
                listBox1.Show();
            }
        }

        private void CheatScanForm_Load(object sender, EventArgs e)
        {
            button3.Hide();
            button4.Hide();
            button2.Hide();
            label1.Hide();
            label2.Hide();
            listBox1.Hide();
            textBox1.ReadOnly = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            var fileName = @textBox1.Text;

            try
            {

                using (StreamReader reader = new StreamReader(fileName))
                {
                    string line;

                    while ((line = reader.ReadLine()) != null)
                    {
                        for (int i = 0; i < blacklist.Length; i++)
                        {
                            if (line.Contains(blacklist[i]))
                            {
                                totalDetections++;
                                listBox1.Items.Add(coolNamesXD[i]);
                            }
                        }
                        
                    }
                }
                button3.Show();
                button4.Show();
                label1.Show();
                label2.Show();
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
            
            if (totalDetections == 0)
            {
                MessageBox.Show("Nothing found!", "Secure 9", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
            }

            label2.Text = totalDetections.ToString();
            totalDetections = 0;


        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                Clipboard.SetText(listBox1.SelectedItem.ToString());
                MessageBox.Show("Possible or absolute cheat directory has copied to clipboard successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("First, you have to select a item to copy it to clipboard!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                if (listBox1.Items.Count > 0)
                {
                    listBox1.Items.Remove(listBox1.SelectedItem);
                    totalDetections--;
                    label2.Text = totalDetections.ToString();

                }

                    listBox1.SelectedItem = null;
                
                MessageBox.Show("Not serious wrong-detected item has successfully removed from list!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("First, you have to select a item to mark as unimportant!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
          
        }
    }
}
