﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Synclapse_Secure_9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case 0x84:
                    base.WndProc(ref m);
                    if ((int)m.Result == 0x1)
                        m.Result = (IntPtr)0x2;
                    return;
            }

            base.WndProc(ref m);
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ProcessScanForm xf1 = new ProcessScanForm();
            xf1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CheatScanForm xf2 = new CheatScanForm();
            xf2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            VSForm xf3 = new VSForm();
            xf3.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Created by Emre Kütüker - (c)2019-2020 Synclapse Inc. (A Test Project!)\n\n\nDISCLAMIER: You can develop this project, change codes, publish in your own but you are not allowed to SELL this project to anyone. Just develop and have fun.\n\n\n\n Enjoy version 9.0 :)");
            System.Diagnostics.Process.Start("https://github.com/ekutuker");
        }
    }
}
